import "./slider";
import modals from './modules/modals';

window.addEventListener('DOMContentLoaded', () => {
    modals();
});